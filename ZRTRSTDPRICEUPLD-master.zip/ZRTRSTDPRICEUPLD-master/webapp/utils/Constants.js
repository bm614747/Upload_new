sap.ui.define([],
    function() {
        'use strict';
    
        var constants = {
            serviceURL: "/sap/opu/odata/sap/",
            service: "ZRTR_GW_STD_PRC_UPLD_MAT_SRV",
            entitySet: "MaterialsSet",
            semanticObj: "Material",
            action: "display"
        };
    
        return constants;
    });