sap.ui.define([
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageBox"
], function (JSNOModel, MessageBox) {
    "use strict";

    return {
        /**
         * Initialization of events for upload
         * @param {object} 
         *	oRef - Reference of where the commonuploadUI.fragment.xml used.
         *	sService - oData Service name
         *	sUploadEntity - Create stream entity name for upload
         * 
         * 
         */
        init: function (initData) {
            this.initData = initData;            
            initData.oRef.getView().setModel(new JSNOModel([]), "EXCEL_RESULTS_MODEL");

            //  Called if mismatch in file type
            initData.oRef.byId("idFileUploader").attachTypeMissmatch(function () {
                MessageBox.error(initData.oRef.getView().getModel("i18n").getResourceBundle().getText("messageBoxError"));
            }.bind(initData.oRef));
        },

        //change event
        handleUploadChange: function (oEvent) {
            if (oEvent.getParameter("files") && oEvent.getParameter("files")[0]) {
                this.addHeaderParameters();
            }
        },

        //Add header parameters and sets the uplodUrl
        addHeaderParameters: function () {
            this.initData.oRef.getView().setBusy(true);
            if (this.initData.oRef.getView().byId("idChkBox").getSelected()) {
                this.sTestRunValue = "X";
            } else {
                this.sTestRunValue = "";
            }
            var oCustomerHeaderToken = new sap.ui.unified.FileUploaderParameter({
                name: "x-csrf-token",
                value: this.initData.oRef.getView().getModel().getSecurityToken()
            });
            this.initData.oRef.getView().byId("idFileUploader").addHeaderParameter(oCustomerHeaderToken);
            var oSlug;
            if (this.sTestRunValue) {
                this.initData.oRef.getView().byId("idFileUploader").removeAllHeaderParameters();
                oSlug = new sap.ui.unified.FileUploaderParameter({
                    name: "slug",
                    value: this.initData.oRef.getView().byId("idFileUploader").getValue() + "|" + this.sTestRunValue
                });
                this.initData.oRef.getView().byId("idFileUploader").addHeaderParameter(oCustomerHeaderToken);
                this.initData.oRef.getView().byId("idFileUploader").addHeaderParameter(oSlug);
            } else {
                oSlug = new sap.ui.unified.FileUploaderParameter({
                    name: "slug",
                    value: this.initData.oRef.getView().byId("idFileUploader").getValue()
                });
                this.initData.oRef.getView().byId("idFileUploader").addHeaderParameter(oSlug);
            }

            var sUploadURL = this.initData.sServiceURL + this.initData.sService + "/" + this.initData.sUploadEntity;
            this.initData.oRef.getView().byId("idFileUploader").setUploadUrl(sUploadURL);
            this.initData.oRef.getView().setBusy(false);
        },

        //upload complete method 
        handleComplete: function (oEvent) {
            var oResponse = (new window.DOMParser()).parseFromString(oEvent.getParameter("responseRaw"), "text/xml");
            if (oResponse.getElementsByTagName("errordetails").length > 0) {
                var aErrors = oResponse.getElementsByTagName("errordetails")[0].children[0];
                var aErrorMsg = aErrors.getElementsByTagName("message")[0].innerHTML;                
                MessageBox.error(aErrorMsg);
            } else if (oResponse.childNodes[0].children[6].children.length > 0) {
                var aItem = oResponse.childNodes[0].children[6].children[2];
                this.parseMessages(aItem.innerHTML);
            }
            this.initData.oRef.getView().byId("idFileUploader").clear();
            this.initData.oRef.getView().byId("idChkBox").setSelected(false);
            this.initData.oRef.getView().byId("idFileUploader").removeAllHeaderParameters();
            this.initData.oRef.getView().setBusy(false);
        },

        //Parsing data and assigning to objects
        parseMessages: function (aItem) {
            var aExcelData = [];
            var aData = aItem.split("\n");
            for (var i = 0; i <= aData.length - 2; i++) {
                var oExcelObjects = {};
                oExcelObjects.TARGET_FIELD = aData[i].split("||")[0];
                oExcelObjects.MATERIAL = aData[i].split("||")[1];
                oExcelObjects.MAT_DESCR = aData[i].split("||")[2];
                oExcelObjects.PLANT = aData[i].split("||")[3];
                oExcelObjects.PLANT_DESCR = aData[i].split("||")[4];
                oExcelObjects.OLD_PRICE = aData[i].split("||")[5];
                oExcelObjects.OLD_CURRENCY = aData[i].split("||")[6];
                oExcelObjects.NEW_PRICE_BASE = aData[i].split("||")[7];
                oExcelObjects.NEW_CURR_BASE = aData[i].split("||")[8];
                oExcelObjects.NEW_PRICE_UT = aData[i].split("||")[9];
                oExcelObjects.NEW_CURR_UT = aData[i].split("||")[10];
                oExcelObjects.PRICE_DATE = aData[i].split("||")[11];
                oExcelObjects.PRICE_UNIT = aData[i].split("||")[12];
                oExcelObjects.UOM = aData[i].split("||")[13];
                oExcelObjects.INPUT_UOM = aData[i].split("||")[14];
                oExcelObjects.STATUS = aData[i].split("||")[15];
                oExcelObjects.MESSAGE = aData[i].split("||")[16];
                aExcelData.push(oExcelObjects);
            }

            // Setting data to the model
            this.initData.oRef.getView().getModel("EXCEL_RESULTS_MODEL").setData(aExcelData);
        }
    };
});