/* global QUnit */

sap.ui.require(["zz1rtrstdpriceupld/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
