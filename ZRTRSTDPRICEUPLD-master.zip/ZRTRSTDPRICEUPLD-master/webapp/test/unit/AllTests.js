sap.ui.define([
	"zz1_rtrstdpriceupld/test/unit/controller/StdPriceUpld.controller"
], function () {
	"use strict";
});
