/*global QUnit*/

sap.ui.define([
	"zz1_rtrstdpriceupld/controller/StdPriceUpld.controller"
], function (Controller) {
	"use strict";

	QUnit.module("StdPriceUpld Controller");

	QUnit.test("I should test the StdPriceUpld controller", function (assert) {
		var oAppController = new Controller();
		oAppController.onInit();
		assert.ok(oAppController);
	});

});
