sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "zz1rtrstdpriceupld/utils/CommonUpload",
    "zz1rtrstdpriceupld/utils/Constants",
    "sap/ui/export/library",
    "sap/ui/export/Spreadsheet",
    "sap/m/MessageBox"
],
    /**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (Controller, CommonUpload, Constants, exportLibrary, Spreadsheet, MessageBox) {
        "use strict";
        var EdmType = exportLibrary.EdmType;

        return Controller.extend("zz1rtrstdpriceupld.controller.StdPriceUpld", {
            onInit: function () {
                // Passing reference of contansts to utility file for data upload
                CommonUpload.init({
                    oRef: this,
                    sServiceURL: Constants.serviceURL,
                    sService: Constants.service,
                    sUploadEntity: Constants.entitySet
                })
            },

            // Function to hadle Cross App Navigation  
            handleClick: function (oEvent) {
                var oShell = sap.ushell.Container.getService("CrossApplicationNavigation");
                oShell.toExternal({
                    target: { semanticObject: Constants.semanticObj, action: Constants.action },
                    params: { Material: oEvent.getSource().mProperties.text }
                });
            },

            // Function to export data in table    
            onExport: function (stype) {
                var aCols, aProducts, oSettings, oSheet, sExcelFileName;

                if (stype === "Template") {
                    aCols = this.createTemplateColumns();
                    aProducts = [{
                        "TARGET_FIELD": "",
                        "MATERIAL": "",
                        "MAT_DESCR": "",
                        "PLANT": "",
                        "PLANT_DESCR": "",
                        "OLD_PRICE": "",
                        "OLD_CURRENCY": "", 
                        "NEW_PRICE_BASE": "",
                        "NEW_CURR_BASE": "",  
                        "NEW_PRICE_UT": "",
                        "NEW_CURR_UT": "",
                        "PRICE_DATE": "",     
                        "PRICE_UNIT": "",     
                        "UOM": "",           
                        "STATUS": "",         
                        "MESSAGE": ""                            
                    }];               
                    sExcelFileName = this.getView().getModel("i18n").getResourceBundle().getText("template");    
                } else {
                    aCols = this.createTblColumns();
                    aProducts = this.getView().getModel("EXCEL_RESULTS_MODEL").getData();
                    sExcelFileName = this.getView().getModel("i18n").getResourceBundle().getText("tableData");
                }              
                
                oSettings = {
                    workbook: { columns: aCols },
                    dataSource: aProducts,
                    count: aProducts.length,
                    fileName: sExcelFileName,
                    wrap: true
                };

                oSheet = new Spreadsheet(oSettings);
                oSheet.build()
                    .then(function () {
                        MessageBox.information(this.getView().getModel("i18n").getResourceBundle().getText("messageBoxInformation"));
                    })
                    .finally(oSheet.destroy);
            },

            // Building labels & properties for excel
            createTblColumns: function () {
                return [
                    {
                        label: this.getView().getModel("i18n").getResourceBundle().getText("targetField"),
                        property: 'TARGET_FIELD',
                        type: EdmType.String,
                        width: 11
                        
                    },
                    {
                        label: this.getView().getModel("i18n").getResourceBundle().getText("materialNo"),
                        property: 'MATERIAL',
                        type: EdmType.String,
                        width: 11
                    },
                    {
                        label: this.getView().getModel("i18n").getResourceBundle().getText("matDesc"),
                        property: 'MAT_DESCR',
                        type: EdmType.String,
                        width: 11
                    },
                    {
                        label: this.getView().getModel("i18n").getResourceBundle().getText("plantNo"),
                        property: 'PLANT',
                        type: EdmType.String,
                        width: 11
                    },
                    {
                        label: this.getView().getModel("i18n").getResourceBundle().getText("plantDesc"),
                        property: 'PLANT_DESCR',
                        type: EdmType.String,
                        width: 11
                    },
                    {
                        label: this.getView().getModel("i18n").getResourceBundle().getText("oldPrice"),
                        property: 'OLD_PRICE',
                        type: EdmType.String,
                        width: 11
                    },
                    {
                        label: this.getView().getModel("i18n").getResourceBundle().getText("oldPriceCurreny"),
                        property: 'OLD_CURRENCY',
                        type: EdmType.String,
                        width: 11
                    },
                    {
                        label: this.getView().getModel("i18n").getResourceBundle().getText("newPriceBase"),
                        property: 'NEW_PRICE_BASE',
                        type: EdmType.String,
                        width: 11
                    },
                    {
                        label: this.getView().getModel("i18n").getResourceBundle().getText("newPriceCurrencyBase"),
                        property: 'NEW_CURR_BASE',
                        type: EdmType.String,
                        width: 11
                    },
                    {
                        label: this.getView().getModel("i18n").getResourceBundle().getText("newPriceInput"),
                        property: 'NEW_PRICE_UT',
                        type: EdmType.String,
                        width: 11
                    },                    
                    {
                        label: this.getView().getModel("i18n").getResourceBundle().getText("newPriceCurrencyInput"),
                        property: 'NEW_CURR_UT',
                        type: EdmType.String,
                        width: 11
                    }, 
                    {
                        label: this.getView().getModel("i18n").getResourceBundle().getText("priceDate"),
                        property: 'PRICE_DATE',
                        type: EdmType.String,
                        width: 11
                    },                    
                    {
                        label: this.getView().getModel("i18n").getResourceBundle().getText("priceUnit"),
                        property: 'PRICE_UNIT',
                        type: EdmType.String,
                        width: 11
                    },   
                    {
                        label: this.getView().getModel("i18n").getResourceBundle().getText("baseUOM"),
                        property: 'UOM',
                        type: EdmType.String,
                        width: 11
                    },                 
                    {
                        label: this.getView().getModel("i18n").getResourceBundle().getText("inputUOM"),
                        property: 'INPUT_UOM',
                        type: EdmType.String,
                        width: 11
                    },
                    {
                        label: this.getView().getModel("i18n").getResourceBundle().getText("status"),
                        property: 'STATUS',
                        type: EdmType.String,
                        width: 11
                    },
                    {
                        label: this.getView().getModel("i18n").getResourceBundle().getText("message"),
                        property: 'MESSAGE',
                        type: EdmType.String,
                        width: 11
                    },
                ];
            },

            // Building labels & properties for template excel
            createTemplateColumns: function () {
                return [
                    {
                        label: this.getView().getModel("i18n").getResourceBundle().getText("targetFieldM"),
                        property: 'TARGET_FIELD',
                        type: EdmType.String
                    },
                    {
                        label: this.getView().getModel("i18n").getResourceBundle().getText("materialNoM"),
                        property: 'MATERIAL',
                        type: EdmType.String
                    },
                    {
                        label: this.getView().getModel("i18n").getResourceBundle().getText("plantNoM"),
                        property: 'MAT_DESCR',
                        type: EdmType.String
                    },
                    {
                        label: this.getView().getModel("i18n").getResourceBundle().getText("stdPriceTemplate"),
                        property: 'GRADE',
                        type: EdmType.String
                    },
                    {
                        label: this.getView().getModel("i18n").getResourceBundle().getText("currency"),
                        property: 'TENDENCY',
                        type: EdmType.String
                    },                    
                    {
                        label: this.getView().getModel("i18n").getResourceBundle().getText("priceUnitM"),
                        property: 'PRICE_UNIT',
                        type: EdmType.String
                    },
                    {
                        label: this.getView().getModel("i18n").getResourceBundle().getText("valuationUOM"),
                        property: 'UOM',
                        type: EdmType.String
                    },
                    {
                        label: this.getView().getModel("i18n").getResourceBundle().getText("priceDateTemplate"),
                        property: 'PRICE_DATE',
                        type: EdmType.String
                    },
                    {
                        label: this.getView().getModel("i18n").getResourceBundle().getText("valuationType"),
                        property: 'RUNMSG',
                        type: EdmType.String
                    },
                ];
            },

            // change event of File uploader
            onUploadChange: function (oEvent) {
                // Calling change function in utility file
                CommonUpload.handleUploadChange(oEvent);
            },

            // Function to handle test run funcitonality
            handleSelect: function () {
                // Calling add header function in utility file
                CommonUpload.addHeaderParameters();
            },

            // Submit button function
            handlePress: function (oEvent) {
                if (this.byId("idFileUploader").getValue()) {
                    this.getView().setBusy(true);                    
                    // Calling standard function of file uploader control                
                    this.byId("idFileUploader").upload();
                } else {
                    MessageBox.error(this.getView().getModel("i18n").getResourceBundle().getText("messageBoxError"));
                }
            },

            // Function to download template 
            handleDownloadTemplate: function (oEvent) {
                this.onExport("Template");                
            },

            // Event for upload complete
            handleUploadComplete: function (oEvent) {
                // Calling upload complete function in utility file
                CommonUpload.handleComplete(oEvent);
            }
        });
    });
