## Modification Log
User - USS1089 Srinivasan Seetharaman, Date: 30th November, 2022 - First commit of custom UI5 app for Standard price upload for raw materials
User - USS1089 Srinivasan Seetharaman, Date: 2nd December, 2022 - New changes from Stella (Addition of column, rename of template file label), Implemented review comments from Sherly

## Application Details
|               |
| ------------- |
|**Generation Date and Time**<br>Fri Nov 18 2022 08:29:36 GMT+0000 (Coordinated Universal Time)|
|**App Generator**<br>@sap/generator-fiori-freestyle|
|**App Generator Version**<br>1.8.1|
|**Generation Platform**<br>SAP Business Application Studio|
|**Template Used**<br>simple|
|**Service Type**<br>SAP System (ABAP On Premise)|
|**Service URL**<br>http://bass4hdev.sap.lambweston.com:443/sap/opu/odata/sap/ZRTR_GW_STD_PRC_UPLD_MAT_SRV
|**Module Name**<br>zz1_rtrstdpriceupld|
|**Application Title**<br>Standard Price Upload for Raw Materials|
|**Namespace**<br>|
|**UI5 Theme**<br>sap_fiori_3|
|**UI5 Version**<br>1.84.23|
|**Enable Code Assist Libraries**<br>False|
|**Enable TypeScript**<br>False|
|**Add Eslint configuration**<br>False|

## zz1_rtrstdpriceupld

A custom freestyle app for Standard Price Upload for Raw Materials

### Starting the generated app

-   This app has been generated using the SAP Fiori tools - App Generator, as part of the SAP Fiori tools suite.  In order to launch the generated app, simply run the following from the generated app root folder:

```
    npm start
```

- It is also possible to run the application using mock data that reflects the OData Service URL supplied during application generation.  In order to run the application with Mock Data, run the following from the generated app root folder:

```
    npm run start-mock
```

#### Pre-requisites:

1. Active NodeJS LTS (Long Term Support) version and associated supported NPM version.  (See https://nodejs.org)


